﻿namespace UIs
{
    partial class uclaythongtinphitre
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnlaydsphitre = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtmakhachhang = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblloaidia = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbltuade = new System.Windows.Forms.Label();
            this.lbltongsotienno = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblmadia = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblsodienthoaikhachhang = new System.Windows.Forms.Label();
            this.lbltenkhachhang = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnlaydsphitre
            // 
            this.btnlaydsphitre.Location = new System.Drawing.Point(748, 8);
            this.btnlaydsphitre.Name = "btnlaydsphitre";
            this.btnlaydsphitre.Size = new System.Drawing.Size(115, 36);
            this.btnlaydsphitre.TabIndex = 24;
            this.btnlaydsphitre.Text = "Lấy danh sách phí trễ";
            this.btnlaydsphitre.UseVisualStyleBackColor = true;
            this.btnlaydsphitre.Click += new System.EventHandler(this.btnlaydsphitre_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 64);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(457, 129);
            this.dataGridView1.TabIndex = 22;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // txtmakhachhang
            // 
            this.txtmakhachhang.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmakhachhang.Location = new System.Drawing.Point(13, 17);
            this.txtmakhachhang.Name = "txtmakhachhang";
            this.txtmakhachhang.Size = new System.Drawing.Size(729, 20);
            this.txtmakhachhang.TabIndex = 21;
            this.txtmakhachhang.Text = "Mã khách hàng";
            this.txtmakhachhang.Click += new System.EventHandler(this.txtmakhachhang_Click);
            this.txtmakhachhang.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtmakhachhang_KeyUp);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.lblloaidia);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.lbltuade);
            this.groupBox6.Controls.Add(this.lbltongsotienno);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Controls.Add(this.lblmadia);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.lblsodienthoaikhachhang);
            this.groupBox6.Controls.Add(this.lbltenkhachhang);
            this.groupBox6.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(3, 199);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(470, 490);
            this.groupBox6.TabIndex = 23;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Thông tin chi tiết";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 202);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 18);
            this.label8.TabIndex = 7;
            this.label8.Text = "Loại đĩa";
            // 
            // lblloaidia
            // 
            this.lblloaidia.AutoSize = true;
            this.lblloaidia.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblloaidia.Location = new System.Drawing.Point(223, 202);
            this.lblloaidia.Name = "lblloaidia";
            this.lblloaidia.Size = new System.Drawing.Size(63, 18);
            this.lblloaidia.TabIndex = 7;
            this.lblloaidia.Text = "Loại đĩa";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tổng phí trễ : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(20, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "Tựa đĩa";
            // 
            // lbltuade
            // 
            this.lbltuade.AutoSize = true;
            this.lbltuade.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltuade.Location = new System.Drawing.Point(223, 163);
            this.lbltuade.Name = "lbltuade";
            this.lbltuade.Size = new System.Drawing.Size(60, 18);
            this.lbltuade.TabIndex = 7;
            this.lbltuade.Text = "Tựa đĩa";
            // 
            // lbltongsotienno
            // 
            this.lbltongsotienno.AutoSize = true;
            this.lbltongsotienno.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltongsotienno.Location = new System.Drawing.Point(222, 241);
            this.lbltongsotienno.Name = "lbltongsotienno";
            this.lbltongsotienno.Size = new System.Drawing.Size(102, 19);
            this.lbltongsotienno.TabIndex = 7;
            this.lbltongsotienno.Text = "Tổng số tiền nợ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 18);
            this.label6.TabIndex = 7;
            this.label6.Text = "Mã đĩa bị trả trễ";
            // 
            // lblmadia
            // 
            this.lblmadia.AutoSize = true;
            this.lblmadia.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmadia.Location = new System.Drawing.Point(223, 124);
            this.lblmadia.Name = "lblmadia";
            this.lblmadia.Size = new System.Drawing.Size(107, 19);
            this.lblmadia.TabIndex = 7;
            this.lblmadia.Text = "Mã đĩa bị trả trễ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "Tên khách hàng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 18);
            this.label5.TabIndex = 7;
            this.label5.Text = "Số điện thoại khách hàng";
            // 
            // lblsodienthoaikhachhang
            // 
            this.lblsodienthoaikhachhang.AutoSize = true;
            this.lblsodienthoaikhachhang.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsodienthoaikhachhang.Location = new System.Drawing.Point(223, 85);
            this.lblsodienthoaikhachhang.Name = "lblsodienthoaikhachhang";
            this.lblsodienthoaikhachhang.Size = new System.Drawing.Size(182, 18);
            this.lblsodienthoaikhachhang.TabIndex = 7;
            this.lblsodienthoaikhachhang.Text = "Số điện thoại khách hàng";
            // 
            // lbltenkhachhang
            // 
            this.lbltenkhachhang.AutoSize = true;
            this.lbltenkhachhang.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltenkhachhang.Location = new System.Drawing.Point(223, 50);
            this.lbltenkhachhang.Name = "lbltenkhachhang";
            this.lbltenkhachhang.Size = new System.Drawing.Size(120, 18);
            this.lbltenkhachhang.TabIndex = 7;
            this.lbltenkhachhang.Text = "Tên khách hàng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(499, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Ảnh của đĩa";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(479, 64);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(392, 625);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // uclaythongtinphitre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnlaydsphitre);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtmakhachhang);
            this.Controls.Add(this.groupBox6);
            this.Name = "uclaythongtinphitre";
            this.Size = new System.Drawing.Size(887, 692);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnlaydsphitre;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtmakhachhang;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblloaidia;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbltuade;
        private System.Windows.Forms.Label lbltongsotienno;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblmadia;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblsodienthoaikhachhang;
        private System.Windows.Forms.Label lbltenkhachhang;
    }
}
