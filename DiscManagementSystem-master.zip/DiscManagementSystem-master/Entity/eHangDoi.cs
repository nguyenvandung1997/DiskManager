﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class eHangDoi
    {
        public int ID { get; set; }
        public string MaKhachHang { get; set; }
        public string MaTuaDe { get; set; }
        public int ThuTu { get; set; }
        public int SoLuongDat { get; set; }
    }
}
