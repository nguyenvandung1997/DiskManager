﻿namespace UIs
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btndangxuat = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btndangnhap = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnhuycho = new System.Windows.Forms.Button();
            this.btndatcho = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnbaocaotongsodia = new System.Windows.Forms.Button();
            this.btnbaocaokhoannokhachhang = new System.Windows.Forms.Button();
            this.btnbaocaodiaquahan = new System.Windows.Forms.Button();
            this.btnbaocaothongtincoban = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnxoadia = new System.Windows.Forms.Button();
            this.btnthemdia = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnlaythongtinphitre = new System.Windows.Forms.Button();
            this.btnhuyphitre = new System.Windows.Forms.Button();
            this.btncapnhatphitre = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnxoatua = new System.Windows.Forms.Button();
            this.btnthemtua = new System.Windows.Forms.Button();
            this.btntraloithongtin = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.btnxoakhachhang = new System.Windows.Forms.Button();
            this.btnthemkhachang = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblroll = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnbaocaotinhtrangdia = new System.Windows.Forms.Button();
            this.btnchothuedia = new System.Windows.Forms.Button();
            this.btnghinhantradia = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btndangxuat
            // 
            this.btndangxuat.Enabled = false;
            this.btndangxuat.Location = new System.Drawing.Point(569, 9);
            this.btndangxuat.Name = "btndangxuat";
            this.btndangxuat.Size = new System.Drawing.Size(157, 37);
            this.btndangxuat.TabIndex = 0;
            this.btndangxuat.Text = "Đăng xuất";
            this.btndangxuat.UseVisualStyleBackColor = true;
            this.btndangxuat.Click += new System.EventHandler(this.btndangxuat_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Thistle;
            this.panel2.Controls.Add(this.btndangxuat);
            this.panel2.Controls.Add(this.btndangnhap);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(480, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(890, 51);
            this.panel2.TabIndex = 4;
            // 
            // btndangnhap
            // 
            this.btndangnhap.Location = new System.Drawing.Point(732, 9);
            this.btndangnhap.Name = "btndangnhap";
            this.btndangnhap.Size = new System.Drawing.Size(157, 37);
            this.btndangnhap.TabIndex = 1;
            this.btndangnhap.Text = "Đăng nhập";
            this.btndangnhap.UseVisualStyleBackColor = true;
            this.btndangnhap.Click += new System.EventHandler(this.btndangnhap_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnhuycho);
            this.groupBox5.Controls.Add(this.btndatcho);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(6, 467);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(447, 67);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Quản lý đặt đĩa";
            // 
            // btnhuycho
            // 
            this.btnhuycho.Location = new System.Drawing.Point(227, 22);
            this.btnhuycho.Name = "btnhuycho";
            this.btnhuycho.Size = new System.Drawing.Size(215, 30);
            this.btnhuycho.TabIndex = 1;
            this.btnhuycho.Text = "Hủy chỗ";
            this.btnhuycho.UseVisualStyleBackColor = true;
            this.btnhuycho.Click += new System.EventHandler(this.btnhuycho_Click);
            // 
            // btndatcho
            // 
            this.btndatcho.Location = new System.Drawing.Point(6, 22);
            this.btndatcho.Name = "btndatcho";
            this.btndatcho.Size = new System.Drawing.Size(215, 30);
            this.btndatcho.TabIndex = 0;
            this.btndatcho.Text = "Đặt chỗ";
            this.btndatcho.UseVisualStyleBackColor = true;
            this.btndatcho.Click += new System.EventHandler(this.btndatcho_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Thistle;
            this.panel1.Controls.Add(this.groupBox7);
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblroll);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(480, 749);
            this.panel1.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btnbaocaotongsodia);
            this.groupBox7.Controls.Add(this.btnbaocaokhoannokhachhang);
            this.groupBox7.Controls.Add(this.btnbaocaodiaquahan);
            this.groupBox7.Controls.Add(this.btnbaocaothongtincoban);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(6, 613);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(447, 124);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Lập báo cáo quản lý khách hàng";
            // 
            // btnbaocaotongsodia
            // 
            this.btnbaocaotongsodia.Enabled = false;
            this.btnbaocaotongsodia.Location = new System.Drawing.Point(227, 22);
            this.btnbaocaotongsodia.Name = "btnbaocaotongsodia";
            this.btnbaocaotongsodia.Size = new System.Drawing.Size(215, 46);
            this.btnbaocaotongsodia.TabIndex = 1;
            this.btnbaocaotongsodia.Text = "Tổng số đĩa khách hàng đang có";
            this.btnbaocaotongsodia.UseVisualStyleBackColor = true;
            this.btnbaocaotongsodia.Click += new System.EventHandler(this.btnbaocaotongsodia_Click);
            // 
            // btnbaocaokhoannokhachhang
            // 
            this.btnbaocaokhoannokhachhang.Enabled = false;
            this.btnbaocaokhoannokhachhang.Location = new System.Drawing.Point(226, 74);
            this.btnbaocaokhoannokhachhang.Name = "btnbaocaokhoannokhachhang";
            this.btnbaocaokhoannokhachhang.Size = new System.Drawing.Size(215, 46);
            this.btnbaocaokhoannokhachhang.TabIndex = 3;
            this.btnbaocaokhoannokhachhang.Text = "Thông tin khoản nợ của khách hàng";
            this.btnbaocaokhoannokhachhang.UseVisualStyleBackColor = true;
            this.btnbaocaokhoannokhachhang.Click += new System.EventHandler(this.btnbaocaokhoannokhachhang_Click);
            // 
            // btnbaocaodiaquahan
            // 
            this.btnbaocaodiaquahan.Enabled = false;
            this.btnbaocaodiaquahan.Location = new System.Drawing.Point(6, 74);
            this.btnbaocaodiaquahan.Name = "btnbaocaodiaquahan";
            this.btnbaocaodiaquahan.Size = new System.Drawing.Size(215, 46);
            this.btnbaocaodiaquahan.TabIndex = 2;
            this.btnbaocaodiaquahan.Text = "Thông tin đĩa đã quá hạn trả";
            this.btnbaocaodiaquahan.UseVisualStyleBackColor = true;
            this.btnbaocaodiaquahan.Click += new System.EventHandler(this.btnbaocaodiaquahan_Click);
            // 
            // btnbaocaothongtincoban
            // 
            this.btnbaocaothongtincoban.Enabled = false;
            this.btnbaocaothongtincoban.Location = new System.Drawing.Point(6, 22);
            this.btnbaocaothongtincoban.Name = "btnbaocaothongtincoban";
            this.btnbaocaothongtincoban.Size = new System.Drawing.Size(215, 46);
            this.btnbaocaothongtincoban.TabIndex = 0;
            this.btnbaocaothongtincoban.Text = "Tên và thông tin cơ bản";
            this.btnbaocaothongtincoban.UseVisualStyleBackColor = true;
            this.btnbaocaothongtincoban.Click += new System.EventHandler(this.btnbaocaothongtincoban_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnxoadia);
            this.groupBox6.Controls.Add(this.btnthemdia);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(6, 540);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(447, 67);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Quản lý kho đĩa";
            // 
            // btnxoadia
            // 
            this.btnxoadia.Enabled = false;
            this.btnxoadia.Location = new System.Drawing.Point(227, 22);
            this.btnxoadia.Name = "btnxoadia";
            this.btnxoadia.Size = new System.Drawing.Size(215, 30);
            this.btnxoadia.TabIndex = 1;
            this.btnxoadia.Text = "Xóa đĩa";
            this.btnxoadia.UseVisualStyleBackColor = true;
            this.btnxoadia.Click += new System.EventHandler(this.btnxoadia_Click);
            // 
            // btnthemdia
            // 
            this.btnthemdia.Enabled = false;
            this.btnthemdia.Location = new System.Drawing.Point(6, 22);
            this.btnthemdia.Name = "btnthemdia";
            this.btnthemdia.Size = new System.Drawing.Size(215, 30);
            this.btnthemdia.TabIndex = 0;
            this.btnthemdia.Text = "Thêm đĩa";
            this.btnthemdia.UseVisualStyleBackColor = true;
            this.btnthemdia.Click += new System.EventHandler(this.btnthemdia_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnlaythongtinphitre);
            this.groupBox4.Controls.Add(this.btnhuyphitre);
            this.groupBox4.Controls.Add(this.btncapnhatphitre);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(6, 362);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(447, 99);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Quản lý hồ sơ khách hàng về những khoản bị quá hạn ";
            // 
            // btnlaythongtinphitre
            // 
            this.btnlaythongtinphitre.Location = new System.Drawing.Point(227, 22);
            this.btnlaythongtinphitre.Name = "btnlaythongtinphitre";
            this.btnlaythongtinphitre.Size = new System.Drawing.Size(215, 30);
            this.btnlaythongtinphitre.TabIndex = 1;
            this.btnlaythongtinphitre.Text = "Lấy thông tin phí trễ";
            this.btnlaythongtinphitre.UseVisualStyleBackColor = true;
            this.btnlaythongtinphitre.Click += new System.EventHandler(this.btnlaythongtinphitre_Click);
            // 
            // btnhuyphitre
            // 
            this.btnhuyphitre.Enabled = false;
            this.btnhuyphitre.Location = new System.Drawing.Point(6, 58);
            this.btnhuyphitre.Name = "btnhuyphitre";
            this.btnhuyphitre.Size = new System.Drawing.Size(215, 30);
            this.btnhuyphitre.TabIndex = 2;
            this.btnhuyphitre.Text = "Hủy phí trễ";
            this.btnhuyphitre.UseVisualStyleBackColor = true;
            this.btnhuyphitre.Click += new System.EventHandler(this.btnhuyphitre_Click);
            // 
            // btncapnhatphitre
            // 
            this.btncapnhatphitre.Location = new System.Drawing.Point(6, 22);
            this.btncapnhatphitre.Name = "btncapnhatphitre";
            this.btncapnhatphitre.Size = new System.Drawing.Size(215, 30);
            this.btncapnhatphitre.TabIndex = 0;
            this.btncapnhatphitre.Text = "Cập nhật phí trễ";
            this.btncapnhatphitre.UseVisualStyleBackColor = true;
            this.btncapnhatphitre.Click += new System.EventHandler(this.btncapnhatphitre_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnxoatua);
            this.groupBox3.Controls.Add(this.btnthemtua);
            this.groupBox3.Controls.Add(this.btntraloithongtin);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 258);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(447, 98);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Quản lý tựa đĩa có sẵn";
            // 
            // btnxoatua
            // 
            this.btnxoatua.Enabled = false;
            this.btnxoatua.Location = new System.Drawing.Point(226, 22);
            this.btnxoatua.Name = "btnxoatua";
            this.btnxoatua.Size = new System.Drawing.Size(215, 30);
            this.btnxoatua.TabIndex = 1;
            this.btnxoatua.Text = "Xóa tựa";
            this.btnxoatua.UseVisualStyleBackColor = true;
            this.btnxoatua.Click += new System.EventHandler(this.btnxoatua_Click);
            // 
            // btnthemtua
            // 
            this.btnthemtua.Enabled = false;
            this.btnthemtua.Location = new System.Drawing.Point(6, 22);
            this.btnthemtua.Name = "btnthemtua";
            this.btnthemtua.Size = new System.Drawing.Size(215, 30);
            this.btnthemtua.TabIndex = 0;
            this.btnthemtua.Text = "Thêm tựa";
            this.btnthemtua.UseVisualStyleBackColor = true;
            this.btnthemtua.Click += new System.EventHandler(this.btnthemtua_Click);
            // 
            // btntraloithongtin
            // 
            this.btntraloithongtin.Location = new System.Drawing.Point(6, 58);
            this.btntraloithongtin.Name = "btntraloithongtin";
            this.btntraloithongtin.Size = new System.Drawing.Size(215, 30);
            this.btntraloithongtin.TabIndex = 2;
            this.btntraloithongtin.Text = "Trả lời thông tin về một tựa đề đĩa";
            this.btntraloithongtin.UseVisualStyleBackColor = true;
            this.btntraloithongtin.Click += new System.EventHandler(this.btntraloithongtin_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.btnxoakhachhang);
            this.groupBox2.Controls.Add(this.btnthemkhachang);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(6, 167);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(447, 94);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Quản lý khách hàng";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(226, 22);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(215, 30);
            this.button3.TabIndex = 1;
            this.button3.Text = "Cập nhật thông tin khách hàng";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnxoakhachhang
            // 
            this.btnxoakhachhang.Enabled = false;
            this.btnxoakhachhang.Location = new System.Drawing.Point(6, 58);
            this.btnxoakhachhang.Name = "btnxoakhachhang";
            this.btnxoakhachhang.Size = new System.Drawing.Size(215, 30);
            this.btnxoakhachhang.TabIndex = 2;
            this.btnxoakhachhang.Text = "Xóa khách hàng";
            this.btnxoakhachhang.UseVisualStyleBackColor = true;
            this.btnxoakhachhang.Click += new System.EventHandler(this.btnxoakhachhang_Click);
            // 
            // btnthemkhachang
            // 
            this.btnthemkhachang.Location = new System.Drawing.Point(6, 22);
            this.btnthemkhachang.Name = "btnthemkhachang";
            this.btnthemkhachang.Size = new System.Drawing.Size(215, 30);
            this.btnthemkhachang.TabIndex = 0;
            this.btnthemkhachang.Text = "Thêm khách hàng";
            this.btnthemkhachang.UseVisualStyleBackColor = true;
            this.btnthemkhachang.Click += new System.EventHandler(this.btnthemkhachang_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(469, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "---------------------------------------------------------------------------------" +
    "-------------------------------------------------------------------------";
            // 
            // lblroll
            // 
            this.lblroll.AutoSize = true;
            this.lblroll.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblroll.Location = new System.Drawing.Point(12, 9);
            this.lblroll.Name = "lblroll";
            this.lblroll.Size = new System.Drawing.Size(100, 25);
            this.lblroll.TabIndex = 0;
            this.lblroll.Text = "Nhân viên";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnbaocaotinhtrangdia);
            this.groupBox1.Controls.Add(this.btnchothuedia);
            this.groupBox1.Controls.Add(this.btnghinhantradia);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.groupBox1.Location = new System.Drawing.Point(6, 54);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(447, 94);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quản lý cho thuê và trả đĩa";
            // 
            // btnbaocaotinhtrangdia
            // 
            this.btnbaocaotinhtrangdia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbaocaotinhtrangdia.Location = new System.Drawing.Point(6, 58);
            this.btnbaocaotinhtrangdia.Name = "btnbaocaotinhtrangdia";
            this.btnbaocaotinhtrangdia.Size = new System.Drawing.Size(215, 30);
            this.btnbaocaotinhtrangdia.TabIndex = 2;
            this.btnbaocaotinhtrangdia.Text = "Báo cáo tình trạng của đĩa";
            this.btnbaocaotinhtrangdia.UseVisualStyleBackColor = true;
            this.btnbaocaotinhtrangdia.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnchothuedia
            // 
            this.btnchothuedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchothuedia.Location = new System.Drawing.Point(6, 22);
            this.btnchothuedia.Name = "btnchothuedia";
            this.btnchothuedia.Size = new System.Drawing.Size(215, 30);
            this.btnchothuedia.TabIndex = 0;
            this.btnchothuedia.Text = "Cho thuê đĩa";
            this.btnchothuedia.UseVisualStyleBackColor = true;
            this.btnchothuedia.Click += new System.EventHandler(this.btnchothuedia_Click);
            // 
            // btnghinhantradia
            // 
            this.btnghinhantradia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnghinhantradia.Location = new System.Drawing.Point(227, 22);
            this.btnghinhantradia.Name = "btnghinhantradia";
            this.btnghinhantradia.Size = new System.Drawing.Size(215, 30);
            this.btnghinhantradia.TabIndex = 1;
            this.btnghinhantradia.Text = "Ghi nhận trả đĩa";
            this.btnghinhantradia.UseVisualStyleBackColor = true;
            this.btnghinhantradia.Click += new System.EventHandler(this.btnghinhantradia_Click);
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Location = new System.Drawing.Point(482, 57);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(887, 692);
            this.panel3.TabIndex = 5;
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frmAdmin";
            this.Text = "Hệ thống cửa hàng";
            this.Load += new System.EventHandler(this.frmAdmin_Load);
            this.panel2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btndangxuat;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btndangnhap;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnhuycho;
        private System.Windows.Forms.Button btndatcho;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnlaythongtinphitre;
        private System.Windows.Forms.Button btncapnhatphitre;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btntraloithongtin;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnthemkhachang;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblroll;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnbaocaotinhtrangdia;
        private System.Windows.Forms.Button btnchothuedia;
        private System.Windows.Forms.Button btnghinhantradia;
        private System.Windows.Forms.Button btnhuyphitre;
        private System.Windows.Forms.Button btnxoatua;
        private System.Windows.Forms.Button btnthemtua;
        private System.Windows.Forms.Button btnxoakhachhang;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnbaocaotongsodia;
        private System.Windows.Forms.Button btnbaocaokhoannokhachhang;
        private System.Windows.Forms.Button btnbaocaodiaquahan;
        private System.Windows.Forms.Button btnbaocaothongtincoban;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnxoadia;
        private System.Windows.Forms.Button btnthemdia;
        private System.Windows.Forms.Panel panel3;
    }
}