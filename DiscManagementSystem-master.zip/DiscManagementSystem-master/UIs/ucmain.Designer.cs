﻿namespace UIs
{
    partial class ucmain
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txttitle = new System.Windows.Forms.TextBox();
            this.txttinhtrangdia = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtgia = new System.Windows.Forms.TextBox();
            this.lblmadia = new System.Windows.Forms.Label();
            this.txtloaidia = new System.Windows.Forms.TextBox();
            this.txtthoigianthue = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dgvdia = new System.Windows.Forms.DataGridView();
            this.cbtuade = new System.Windows.Forms.ComboBox();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdia)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label3);
            this.groupBox8.Controls.Add(this.txttitle);
            this.groupBox8.Controls.Add(this.txttinhtrangdia);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Controls.Add(this.txtgia);
            this.groupBox8.Controls.Add(this.lblmadia);
            this.groupBox8.Controls.Add(this.txtloaidia);
            this.groupBox8.Controls.Add(this.txtthoigianthue);
            this.groupBox8.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(388, 330);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(487, 349);
            this.groupBox8.TabIndex = 22;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Thông tin đĩa";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Mã đĩa";
            // 
            // txttitle
            // 
            this.txttitle.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttitle.Location = new System.Drawing.Point(17, 90);
            this.txttitle.Name = "txttitle";
            this.txttitle.Size = new System.Drawing.Size(380, 23);
            this.txttitle.TabIndex = 5;
            this.txttitle.Text = "Tựa đề đĩa";
            // 
            // txttinhtrangdia
            // 
            this.txttinhtrangdia.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttinhtrangdia.Location = new System.Drawing.Point(17, 126);
            this.txttinhtrangdia.Name = "txttinhtrangdia";
            this.txttinhtrangdia.Size = new System.Drawing.Size(380, 23);
            this.txttinhtrangdia.TabIndex = 5;
            this.txttinhtrangdia.Text = "Tình trạng đĩa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(296, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "label4";
            // 
            // txtgia
            // 
            this.txtgia.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgia.Location = new System.Drawing.Point(17, 162);
            this.txtgia.Name = "txtgia";
            this.txtgia.Size = new System.Drawing.Size(380, 23);
            this.txtgia.TabIndex = 5;
            this.txtgia.Text = "Giá";
            // 
            // lblmadia
            // 
            this.lblmadia.AutoSize = true;
            this.lblmadia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmadia.Location = new System.Drawing.Point(124, 43);
            this.lblmadia.Name = "lblmadia";
            this.lblmadia.Size = new System.Drawing.Size(140, 17);
            this.lblmadia.TabIndex = 7;
            this.lblmadia.Text = "DTitleName_Number";
            // 
            // txtloaidia
            // 
            this.txtloaidia.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloaidia.Location = new System.Drawing.Point(17, 198);
            this.txtloaidia.Name = "txtloaidia";
            this.txtloaidia.Size = new System.Drawing.Size(380, 23);
            this.txtloaidia.TabIndex = 5;
            this.txtloaidia.Text = "Thể loại đĩa";
            // 
            // txtthoigianthue
            // 
            this.txtthoigianthue.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtthoigianthue.Location = new System.Drawing.Point(17, 234);
            this.txtthoigianthue.Name = "txtthoigianthue";
            this.txtthoigianthue.Size = new System.Drawing.Size(380, 23);
            this.txtthoigianthue.TabIndex = 5;
            this.txtthoigianthue.Text = "Thời gian tối đa cho phép thuê";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 330);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(379, 353);
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // dgvdia
            // 
            this.dgvdia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdia.Location = new System.Drawing.Point(3, 30);
            this.dgvdia.MultiSelect = false;
            this.dgvdia.Name = "dgvdia";
            this.dgvdia.ReadOnly = true;
            this.dgvdia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvdia.Size = new System.Drawing.Size(872, 294);
            this.dgvdia.TabIndex = 20;
            this.dgvdia.SelectionChanged += new System.EventHandler(this.dgvdia_SelectionChanged);
            // 
            // cbtuade
            // 
            this.cbtuade.FormattingEnabled = true;
            this.cbtuade.Location = new System.Drawing.Point(3, 3);
            this.cbtuade.Name = "cbtuade";
            this.cbtuade.Size = new System.Drawing.Size(872, 21);
            this.cbtuade.TabIndex = 19;
            this.cbtuade.SelectedIndexChanged += new System.EventHandler(this.cbtuade_SelectedIndexChanged);
            this.cbtuade.SelectionChangeCommitted += new System.EventHandler(this.cbtuade_SelectionChangeCommitted);
            // 
            // ucmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dgvdia);
            this.Controls.Add(this.cbtuade);
            this.Name = "ucmain";
            this.Size = new System.Drawing.Size(877, 692);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdia)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttitle;
        private System.Windows.Forms.TextBox txttinhtrangdia;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtgia;
        private System.Windows.Forms.Label lblmadia;
        private System.Windows.Forms.TextBox txtloaidia;
        private System.Windows.Forms.TextBox txtthoigianthue;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dgvdia;
        private System.Windows.Forms.ComboBox cbtuade;
    }
}
