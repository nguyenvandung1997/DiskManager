# DiscManagementSystem
Cho phép chủ cửa hàng cho thuê băng đĩa quản lý việc cho khách hàng thuê đĩa và tình trạng đĩa của cửa hàng
