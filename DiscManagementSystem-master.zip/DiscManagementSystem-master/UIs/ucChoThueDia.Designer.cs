﻿namespace UIs
{
    partial class ucChoThueDia
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnluudulieu = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.lbltongtiendatcoc = new System.Windows.Forms.Label();
            this.lblthongbaophimuon = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txttitle = new System.Windows.Forms.TextBox();
            this.txttinhtrangdia = new System.Windows.Forms.TextBox();
            this.lblalert = new System.Windows.Forms.Label();
            this.txtgia = new System.Windows.Forms.TextBox();
            this.lblmadia = new System.Windows.Forms.Label();
            this.txtloaidia = new System.Windows.Forms.TextBox();
            this.txtmakhachhang = new System.Windows.Forms.TextBox();
            this.txtthoigianthue = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnthanhtoanphimuon = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox10.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnluudulieu
            // 
            this.btnluudulieu.Enabled = false;
            this.btnluudulieu.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnluudulieu.Location = new System.Drawing.Point(672, 629);
            this.btnluudulieu.Name = "btnluudulieu";
            this.btnluudulieu.Size = new System.Drawing.Size(178, 36);
            this.btnluudulieu.TabIndex = 0;
            this.btnluudulieu.Text = ". Cho thuê .";
            this.btnluudulieu.UseVisualStyleBackColor = true;
            this.btnluudulieu.Click += new System.EventHandler(this.btnluudulieu_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label8);
            this.groupBox10.Controls.Add(this.label6);
            this.groupBox10.Controls.Add(this.label9);
            this.groupBox10.Controls.Add(this.label7);
            this.groupBox10.Controls.Add(this.label5);
            this.groupBox10.Controls.Add(this.groupBox1);
            this.groupBox10.Controls.Add(this.lbltongtiendatcoc);
            this.groupBox10.Controls.Add(this.lblthongbaophimuon);
            this.groupBox10.Controls.Add(this.label4);
            this.groupBox10.Controls.Add(this.label3);
            this.groupBox10.Controls.Add(this.txttitle);
            this.groupBox10.Controls.Add(this.txttinhtrangdia);
            this.groupBox10.Controls.Add(this.lblalert);
            this.groupBox10.Controls.Add(this.txtgia);
            this.groupBox10.Controls.Add(this.lblmadia);
            this.groupBox10.Controls.Add(this.txtloaidia);
            this.groupBox10.Controls.Add(this.txtmakhachhang);
            this.groupBox10.Controls.Add(this.txtthoigianthue);
            this.groupBox10.Controls.Add(this.pictureBox1);
            this.groupBox10.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(6, 268);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(857, 387);
            this.groupBox10.TabIndex = 15;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Thông tin đĩa";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Location = new System.Drawing.Point(6, 180);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(417, 167);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách các khoản phí muộn của khách hàng";
            this.groupBox1.Visible = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 29);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(411, 117);
            this.dataGridView2.TabIndex = 0;
            // 
            // lbltongtiendatcoc
            // 
            this.lbltongtiendatcoc.AutoSize = true;
            this.lbltongtiendatcoc.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltongtiendatcoc.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbltongtiendatcoc.Location = new System.Drawing.Point(671, 284);
            this.lbltongtiendatcoc.Name = "lbltongtiendatcoc";
            this.lbltongtiendatcoc.Size = new System.Drawing.Size(0, 16);
            this.lbltongtiendatcoc.TabIndex = 28;
            // 
            // lblthongbaophimuon
            // 
            this.lblthongbaophimuon.AutoSize = true;
            this.lblthongbaophimuon.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblthongbaophimuon.Location = new System.Drawing.Point(429, 312);
            this.lblthongbaophimuon.Name = "lblthongbaophimuon";
            this.lblthongbaophimuon.Size = new System.Drawing.Size(0, 15);
            this.lblthongbaophimuon.TabIndex = 27;
            this.lblthongbaophimuon.Visible = false;
            this.lblthongbaophimuon.TextChanged += new System.EventHandler(this.lblthongbaophimuon_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(474, 284);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 17);
            this.label4.TabIndex = 27;
            this.label4.Text = "Tổng số tiền cần đặt cọc";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(464, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 24;
            this.label3.Text = "Mã đĩa";
            // 
            // txttitle
            // 
            this.txttitle.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttitle.Location = new System.Drawing.Point(567, 63);
            this.txttitle.Name = "txttitle";
            this.txttitle.Size = new System.Drawing.Size(256, 23);
            this.txttitle.TabIndex = 0;
            this.txttitle.Text = "Tựa đề đĩa";
            // 
            // txttinhtrangdia
            // 
            this.txttinhtrangdia.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttinhtrangdia.Location = new System.Drawing.Point(567, 102);
            this.txttinhtrangdia.Name = "txttinhtrangdia";
            this.txttinhtrangdia.Size = new System.Drawing.Size(256, 23);
            this.txttinhtrangdia.TabIndex = 1;
            this.txttinhtrangdia.Text = "Tình trạng đĩa";
            // 
            // lblalert
            // 
            this.lblalert.AutoSize = true;
            this.lblalert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblalert.Location = new System.Drawing.Point(735, 32);
            this.lblalert.Name = "lblalert";
            this.lblalert.Size = new System.Drawing.Size(46, 17);
            this.lblalert.TabIndex = 26;
            this.lblalert.Text = "label4";
            this.lblalert.TextChanged += new System.EventHandler(this.lblalert_TextChanged);
            // 
            // txtgia
            // 
            this.txtgia.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgia.Location = new System.Drawing.Point(567, 141);
            this.txtgia.Name = "txtgia";
            this.txtgia.Size = new System.Drawing.Size(256, 23);
            this.txtgia.TabIndex = 2;
            this.txtgia.Text = "Giá";
            this.txtgia.TextChanged += new System.EventHandler(this.txtgia_TextChanged);
            // 
            // lblmadia
            // 
            this.lblmadia.AutoSize = true;
            this.lblmadia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmadia.Location = new System.Drawing.Point(550, 32);
            this.lblmadia.Name = "lblmadia";
            this.lblmadia.Size = new System.Drawing.Size(140, 17);
            this.lblmadia.TabIndex = 25;
            this.lblmadia.Text = "DTitleName_Number";
            // 
            // txtloaidia
            // 
            this.txtloaidia.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloaidia.Location = new System.Drawing.Point(567, 180);
            this.txtloaidia.Name = "txtloaidia";
            this.txtloaidia.Size = new System.Drawing.Size(256, 23);
            this.txtloaidia.TabIndex = 4;
            this.txtloaidia.Text = "Thể loại đĩa";
            // 
            // txtmakhachhang
            // 
            this.txtmakhachhang.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmakhachhang.Location = new System.Drawing.Point(467, 258);
            this.txtmakhachhang.Name = "txtmakhachhang";
            this.txtmakhachhang.Size = new System.Drawing.Size(356, 23);
            this.txtmakhachhang.TabIndex = 6;
            this.txtmakhachhang.Text = "Nhập mã khách hàng muốn thuê";
            this.txtmakhachhang.Click += new System.EventHandler(this.txtmakhachhang_Click);
            this.txtmakhachhang.TextChanged += new System.EventHandler(this.txtmakhachhang_TextChanged);
            this.txtmakhachhang.Leave += new System.EventHandler(this.txtmakhachhang_Leave);
            this.txtmakhachhang.MouseLeave += new System.EventHandler(this.txtmakhachhang_MouseLeave);
            // 
            // txtthoigianthue
            // 
            this.txtthoigianthue.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtthoigianthue.Location = new System.Drawing.Point(567, 219);
            this.txtthoigianthue.Name = "txtthoigianthue";
            this.txtthoigianthue.Size = new System.Drawing.Size(256, 23);
            this.txtthoigianthue.TabIndex = 5;
            this.txtthoigianthue.Text = "Thời gian tối đa cho phép thuê";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(6, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(417, 358);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(332, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 31);
            this.label1.TabIndex = 26;
            this.label1.Text = "Thông tin thuê đĩa";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.groupBox10);
            this.groupBox6.Controls.Add(this.groupBox9);
            this.groupBox6.Location = new System.Drawing.Point(3, 23);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(869, 600);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label2);
            this.groupBox9.Controls.Add(this.comboBox1);
            this.groupBox9.Controls.Add(this.dataGridView1);
            this.groupBox9.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(6, 34);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(857, 228);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Danh sách đĩa hiện có tại hệ thống";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tựa đề đĩa";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(156, 38);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(515, 24);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 68);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(845, 154);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // btnthanhtoanphimuon
            // 
            this.btnthanhtoanphimuon.Enabled = false;
            this.btnthanhtoanphimuon.Font = new System.Drawing.Font("Georgia", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnthanhtoanphimuon.Location = new System.Drawing.Point(441, 629);
            this.btnthanhtoanphimuon.Name = "btnthanhtoanphimuon";
            this.btnthanhtoanphimuon.Size = new System.Drawing.Size(178, 36);
            this.btnthanhtoanphimuon.TabIndex = 0;
            this.btnthanhtoanphimuon.Text = ". Thanh toán phí muộn .";
            this.btnthanhtoanphimuon.UseVisualStyleBackColor = true;
            this.btnthanhtoanphimuon.Click += new System.EventHandler(this.btnthanhtoanphimuon_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(464, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 17);
            this.label5.TabIndex = 30;
            this.label5.Text = "Tên đĩa";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(464, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 17);
            this.label6.TabIndex = 30;
            this.label6.Text = "Tình trạng đĩa";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(464, 143);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 17);
            this.label7.TabIndex = 30;
            this.label7.Text = "Giá";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(464, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 17);
            this.label8.TabIndex = 30;
            this.label8.Text = "Loại đĩa";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(464, 209);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 34);
            this.label9.TabIndex = 30;
            this.label9.Text = "Cho phép thuê\r\ntối đa";
            // 
            // ucChoThueDia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnthanhtoanphimuon);
            this.Controls.Add(this.btnluudulieu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox6);
            this.Name = "ucChoThueDia";
            this.Size = new System.Drawing.Size(877, 692);
            this.Load += new System.EventHandler(this.ucChoThueDia_Load);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnluudulieu;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label lbltongtiendatcoc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttitle;
        private System.Windows.Forms.TextBox txttinhtrangdia;
        private System.Windows.Forms.Label lblalert;
        private System.Windows.Forms.TextBox txtgia;
        private System.Windows.Forms.Label lblmadia;
        private System.Windows.Forms.TextBox txtloaidia;
        private System.Windows.Forms.TextBox txtmakhachhang;
        private System.Windows.Forms.TextBox txtthoigianthue;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblthongbaophimuon;
        private System.Windows.Forms.Button btnthanhtoanphimuon;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
    }
}
