﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class eNhatKyGhiNo
    {
        public int ID { get; set; }
        public string IDKhachHang { get; set; }
        public int IDDia { get; set; }
        public decimal SoTienNo { get; set; }
    }
}
