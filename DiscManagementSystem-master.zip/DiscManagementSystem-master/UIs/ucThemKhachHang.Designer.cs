﻿namespace UIs
{
    partial class ucThemKhachHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnthemkhachhang = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lblmakhachhang = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.lblalertsodienthoai = new System.Windows.Forms.Label();
            this.lblalertenkhachhang = new System.Windows.Forms.Label();
            this.txtsodienthoai = new System.Windows.Forms.TextBox();
            this.txttenkhachhang = new System.Windows.Forms.TextBox();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnthemkhachhang
            // 
            this.btnthemkhachhang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnthemkhachhang.Location = new System.Drawing.Point(273, 238);
            this.btnthemkhachhang.Name = "btnthemkhachhang";
            this.btnthemkhachhang.Size = new System.Drawing.Size(324, 45);
            this.btnthemkhachhang.TabIndex = 23;
            this.btnthemkhachhang.Text = ". Lưu .";
            this.btnthemkhachhang.UseVisualStyleBackColor = true;
            this.btnthemkhachhang.Click += new System.EventHandler(this.btnthemkhachhang_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(289, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(285, 24);
            this.label3.TabIndex = 25;
            this.label3.Text = "Cung cấp thông tin khách hàng";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.lblmakhachhang);
            this.groupBox8.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(197, 307);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(484, 100);
            this.groupBox8.TabIndex = 26;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Mã khách hàng - dùng để thuê đĩa tại hệ thống";
            // 
            // lblmakhachhang
            // 
            this.lblmakhachhang.AutoSize = true;
            this.lblmakhachhang.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmakhachhang.Location = new System.Drawing.Point(91, 42);
            this.lblmakhachhang.Name = "lblmakhachhang";
            this.lblmakhachhang.Size = new System.Drawing.Size(0, 25);
            this.lblmakhachhang.TabIndex = 7;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.lblalertsodienthoai);
            this.groupBox9.Controls.Add(this.lblalertenkhachhang);
            this.groupBox9.Controls.Add(this.txtsodienthoai);
            this.groupBox9.Controls.Add(this.txttenkhachhang);
            this.groupBox9.Location = new System.Drawing.Point(214, 97);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(452, 167);
            this.groupBox9.TabIndex = 27;
            this.groupBox9.TabStop = false;
            // 
            // lblalertsodienthoai
            // 
            this.lblalertsodienthoai.AutoSize = true;
            this.lblalertsodienthoai.Location = new System.Drawing.Point(135, 121);
            this.lblalertsodienthoai.Name = "lblalertsodienthoai";
            this.lblalertsodienthoai.Size = new System.Drawing.Size(0, 13);
            this.lblalertsodienthoai.TabIndex = 2;
            // 
            // lblalertenkhachhang
            // 
            this.lblalertenkhachhang.AutoSize = true;
            this.lblalertenkhachhang.Location = new System.Drawing.Point(135, 66);
            this.lblalertenkhachhang.Name = "lblalertenkhachhang";
            this.lblalertenkhachhang.Size = new System.Drawing.Size(0, 13);
            this.lblalertenkhachhang.TabIndex = 2;
            // 
            // txtsodienthoai
            // 
            this.txtsodienthoai.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsodienthoai.Location = new System.Drawing.Point(17, 88);
            this.txtsodienthoai.Name = "txtsodienthoai";
            this.txtsodienthoai.Size = new System.Drawing.Size(421, 23);
            this.txtsodienthoai.TabIndex = 1;
            this.txtsodienthoai.Text = "Số điện thoại";
            this.txtsodienthoai.Click += new System.EventHandler(this.txtsodienthoai_Click);
            this.txtsodienthoai.TextChanged += new System.EventHandler(this.txtsodienthoai_TextChanged);
            this.txtsodienthoai.Leave += new System.EventHandler(this.txtsodienthoai_Leave);
            // 
            // txttenkhachhang
            // 
            this.txttenkhachhang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttenkhachhang.Location = new System.Drawing.Point(17, 36);
            this.txttenkhachhang.Name = "txttenkhachhang";
            this.txttenkhachhang.Size = new System.Drawing.Size(421, 23);
            this.txttenkhachhang.TabIndex = 0;
            this.txttenkhachhang.Text = "Tên khách hàng";
            this.txttenkhachhang.Click += new System.EventHandler(this.txttenkhachhang_Click);
            this.txttenkhachhang.TextChanged += new System.EventHandler(this.txttenkhachhang_TextChanged);
            this.txttenkhachhang.Leave += new System.EventHandler(this.txttenkhachhang_Leave);
            // 
            // ucThemKhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnthemkhachhang);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox9);
            this.Name = "ucThemKhachHang";
            this.Size = new System.Drawing.Size(877, 692);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnthemkhachhang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label lblmakhachhang;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label lblalertsodienthoai;
        private System.Windows.Forms.Label lblalertenkhachhang;
        private System.Windows.Forms.TextBox txtsodienthoai;
        private System.Windows.Forms.TextBox txttenkhachhang;
    }
}
